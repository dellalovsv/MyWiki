#!/bin/bash

IFACE="eth1"
VLANS="2-500"

  /sbin/vconfig set_name_type DEV_PLUS_VID_NO_PAD
  VLANS=`echo ${VLANS} | sed 'N;s/\n/ /' |sed 's/,/ /g'`
  for i in $VLANS; do
    if [[ $i =~ - ]]; then
      IFS='-' read -a start_stop <<< "$i"
      for cur_iface in `seq ${start_stop[0]} ${start_stop[1]}`;
      do
        echo "${cur_iface}";
        /sbin/vconfig add ${IFACE} ${cur_iface}
        /bin/ip li set up ${IFACE}.${cur_iface}
      done
    else
    echo "$i";
      /sbin/vconfig add ${IFACE} ${i}
      /bin/ip li set up ${IFACE}.${i}
    fi;
  done
